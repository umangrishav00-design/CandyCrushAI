package com.umang.candycrushai

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs

/** Basic HSV hue classifier. Real Candy Crush themes, blockers and highlights require calibration. */
object BoardVision {
    fun readBoard(bitmap: Bitmap, leftF: Float, topF: Float, rightF: Float, bottomF: Float, rows: Int, cols: Int): Array<IntArray> {
        val result = Array(rows) { IntArray(cols) { -1 } }
        val left = (bitmap.width * leftF).toInt(); val right = (bitmap.width * rightF).toInt()
        val top = (bitmap.height * topF).toInt(); val bottom = (bitmap.height * bottomF).toInt()
        val cellW = (right - left).toFloat() / cols; val cellH = (bottom - top).toFloat() / rows
        val hsv = FloatArray(3)
        for (r in 0 until rows) for (c in 0 until cols) {
            val x = (left + (c + 0.5f) * cellW).toInt().coerceIn(0, bitmap.width - 1)
            val y = (top + (r + 0.5f) * cellH).toInt().coerceIn(0, bitmap.height - 1)
            Color.colorToHSV(bitmap.getPixel(x, y), hsv)
            val hue = hsv[0]; val sat = hsv[1]; val value = hsv[2]
            if (sat < 0.22f || value < 0.24f) { result[r][c] = -1; continue }
            result[r][c] = when {
                hue < 18 || hue >= 345 -> 0 // red
                hue < 48 -> 1 // orange/yellow
                hue < 85 -> 2 // yellow/green
                hue < 165 -> 3 // green
                hue < 250 -> 4 // blue
                else -> 5 // purple
            }
        }
        return result
    }
}
