package com.umang.candycrushai

/**
 * Board solver for a rectangular match-three grid. Unknown cells are -1.
 * This is a heuristic starter, not a complete Candy Crush rules engine.
 */
object BoardSolver {
    data class Move(val r1: Int, val c1: Int, val r2: Int, val c2: Int, val score: Int)

    fun bestMove(board: Array<IntArray>): Move? {
        val rows = board.size
        if (rows == 0) return null
        val cols = board[0].size
        var best: Move? = null
        for (r in 0 until rows) for (c in 0 until cols) {
            if (c + 1 < cols) evaluate(board, r, c, r, c + 1)?.let { if (best == null || it.score > best!!.score) best = it }
            if (r + 1 < rows) evaluate(board, r, c, r + 1, c)?.let { if (best == null || it.score > best!!.score) best = it }
        }
        return best
    }

    private fun evaluate(board: Array<IntArray>, r1: Int, c1: Int, r2: Int, c2: Int): Move? {
        val copy = Array(board.size) { board[it].clone() }
        val tmp = copy[r1][c1]; copy[r1][c1] = copy[r2][c2]; copy[r2][c2] = tmp
        val score = matchScore(copy)
        return if (score > 0) Move(r1, c1, r2, c2, score) else null
    }

    private fun matchScore(b: Array<IntArray>): Int {
        var score = 0
        val rows = b.size; val cols = b[0].size
        for (r in 0 until rows) {
            var c = 0
            while (c < cols) {
                val color = b[r][c]; var end = c + 1
                while (color >= 0 && end < cols && b[r][end] == color) end++
                if (color >= 0 && end - c >= 3) score += (end - c) * 10
                c = end
            }
        }
        for (c in 0 until cols) {
            var r = 0
            while (r < rows) {
                val color = b[r][c]; var end = r + 1
                while (color >= 0 && end < rows && b[end][c] == color) end++
                if (color >= 0 && end - r >= 3) score += (end - r) * 10
                r = end
            }
        }
        return score
    }
}
