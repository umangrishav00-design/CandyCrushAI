package com.umang.candycrushai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlin.math.roundToInt

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var running = false
    private var busy = false
    private var lastMoveAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY
        startForeground(1, notification())
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        startCapture()
        return START_NOT_STICKY
    }

    private fun startCapture() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels; val height = metrics.heightPixels; val density = metrics.densityDpi
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        thread = HandlerThread("CandyAI-Capture").also { it.start() }
        handler = Handler(thread!!.looper)
        virtualDisplay = projection?.createVirtualDisplay("CandyAI", width, height, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
        running = true
        handler?.postDelayed(::tick, 1500)
    }

    private fun tick() {
        if (!running || reader == null) return
        val now = System.currentTimeMillis()
        val image = try { reader?.acquireLatestImage() } catch (_: Exception) { null }
        if (image != null) {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val w = image.width; val h = image.height
            val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bitmap.copyPixelsFromBuffer(buffer)
            image.close()
            // Conservative starter board crop: central/lower screen. Needs calibration for your device/game UI.
            val board = BoardVision.readBoard(bitmap, 0.06f, 0.22f, 0.94f, 0.82f, 9, 9)
            bitmap.recycle()
            val move = BoardSolver.bestMove(board)
            if (!busy && move != null && now - lastMoveAt > 2200) {
                val service = GameAccessibilityService.instance
                if (service != null) {
                    val cellW = (width * (0.94f - 0.06f)) / 9f
                    val cellH = (height * (0.82f - 0.22f)) / 9f
                    val x1 = width * 0.06f + (move.c1 + 0.5f) * cellW
                    val y1 = height * 0.22f + (move.r1 + 0.5f) * cellH
                    val x2 = width * 0.06f + (move.c2 + 0.5f) * cellW
                    val y2 = height * 0.22f + (move.r2 + 0.5f) * cellH
                    busy = true; lastMoveAt = now
                    service.swipe(x1, y1, x2, y2) { busy = false }
                }
            }
        }
        if (running) handler?.postDelayed(::tick, 1100)
    }

    private fun notification(): Notification {
        val channelId = "candy_ai"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Candy Crush AI", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder.setContentTitle("Candy Crush AI is running").setContentText("Screen analysis and move search are active").setSmallIcon(android.R.drawable.ic_media_play).build()
    }

    override fun onDestroy() {
        running = false
        virtualDisplay?.release(); reader?.close(); projection?.stop(); thread?.quitSafely()
        virtualDisplay = null; reader = null; projection = null; thread = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
    }
}
