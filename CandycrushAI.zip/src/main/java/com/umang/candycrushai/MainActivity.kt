package com.umang.candycrushai

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val captureRequest = 4102
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("bot", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply {
            text = "Candy Crush AI"
            textSize = 28f
            setTextColor(0xFF39236F.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Local prototype • board vision + move search + swipe control"
            textSize = 15f
            setPadding(0, 12, 0, 24)
        })
        status = TextView(this).apply { textSize = 14f; text = "Setup: enable Accessibility first, then start screen capture." }
        root.addView(status)
        root.addView(makeButton("1. Enable Accessibility Service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(makeButton("2. Start AI (allow screen capture)") {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
        })
        root.addView(makeButton("Stop AI") {
            stopService(Intent(this, CaptureService::class.java))
            status.text = "Stopped."
        })
        root.addView(TextView(this).apply {
            text = "Keep Candy Crush open on a normal level before starting. The prototype uses an estimated board area; if the detected board is wrong, stop it. Do not use while the phone is unattended."
            textSize = 13f
            setPadding(0, 24, 0, 0)
        })
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 12 }
    }

    @Deprecated("Deprecated in Android API; kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            startForegroundService(intent)
            status.text = "AI running. Open Candy Crush; use Stop AI to end the loop."
        } else status.text = "Screen capture permission was not granted."
    }
}
