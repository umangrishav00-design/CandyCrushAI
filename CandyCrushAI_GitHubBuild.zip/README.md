# Candy Crush AI Android prototype

This is a starter Android project. The GitHub Actions workflow attempts to build a debug APK. A successful build does not guarantee the game-playing logic will work reliably on every device; test carefully and stop it if it makes incorrect moves.

## Build APK
1. Upload the contents of this ZIP to the root of your GitHub repository (extract first; do not upload only this ZIP).
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and tap **Run workflow**.
4. When complete, open the successful run and download the `CandyCrushAI-debug-apk` artifact.
